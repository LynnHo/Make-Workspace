#!/bin/sh

zip -r editorconfig-vim-$*.zip autoload/* doc/* ftdetect/* plugin/*
