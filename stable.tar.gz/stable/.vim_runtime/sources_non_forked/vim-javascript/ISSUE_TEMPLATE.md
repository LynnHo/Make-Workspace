*Requisite minimal reproducible example, formatted as plain text :*

<hr>

#### Optional: concerning jsx.
PLEASE PLEASE PLEASE make sure you have properly
setup and are sourcing this plugin https://github.com/mxw/vim-jsx

WE DO NOT support JSX automatically, you need another plugin to add get this
functionality.

Make sure the bug still exists if you disable all other javascript plugins
except the one noted above, mxw/vim-jsx
